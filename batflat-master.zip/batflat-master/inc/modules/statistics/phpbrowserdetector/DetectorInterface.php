<?php

namespace Inc\Modules\Statistics\PHPBrowserDetector;

interface DetectorInterface
{
}
